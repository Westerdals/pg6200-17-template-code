# Author's comments

This is a template library for PG6200 subject.
Fork this library (to keep it forever, after graduation as well)
If you do changes/fixes you would like to share, create a pull-request and I will look it over before making it the current head.

# Required libraries
- [GLEW](http://glew.sourceforge.net/)
- [GLM](http://glm.g-truc.net/)
- [SDL2](https://www.libsdl.org/)
- [ASSIMP](http://www.assimp.org/)
- [DevIL](http://openil.sourceforge.net/)


# Happy coding guys!